package com.mycompany.ilmo;

public class Main {
    public static void main(String[] args) {
        Ilmo sovellus = new Ilmo();
        sovellus.suorita();
    }
}
